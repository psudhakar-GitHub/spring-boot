package com.cts.employeeserviceapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeServiceAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeServiceAppApplication.class, args);
	}

}
